# ================================================================================
#              CODE STATISTIQUE : VALIDATION N2O GOSAT-2 VS FTIR
# ================================================================================
# Analyse statistique comparative des mesures de concentration en N2O entre
# le satellite GOSAT-2 et les stations FTIR du réseau NDACC
# Période : mars à décembre 2019
# ================================================================================


import numpy as np
import matplotlib.pyplot as plt
from pyhdf.SD import SD, SDC
import h5py
import glob
import datetime
import os
from scipy.stats import pearsonr


# ================================================================================
# I. CONFIGURATION ET PARAMÈTRES
# ================================================================================

# --- 1. Noms des mois ---
noms_mois = [
    "janvier", "février", "mars", "avril", "mai", "juin",
    "juillet", "août", "septembre", "octobre", "novembre", "décembre"
]

# --- 2. Fichiers FTIR ---
chemin_ftir = glob.glob(
    r"C:\Users\gauti\OneDrive\Documents\Cours\PYTHON\REPORT\Data\ftir\2019\*.hdf"
)

# --- 3. Rayon de colocalisation (km) ---
rayon_colocalisation_km = 220

# --- 4. Groupes HDF5 GOSAT-2 ---
groupes_gosat = [
    'CloudInformation',      # 0
    'L1QualityInfo',         # 1
    'Metadata',              # 2
    'RetrievalResult',       # 3
    'SceneAttribute',        # 4
    'SoundingAttribute',     # 5
    'SoundingGeometry'       # 6
]

# --- 5. Datasets HDF5 GOSAT-2 ---
datasets_gosat = [
    'latitude',                            # 0  : latitude pixel (°)
    'longitude',                           # 1  : longitude pixel (°)
    'n2o_profile',                         # 2  : profil N2O (ppmv)
    'pressure_level_profile_CH4',          # 3  : niveaux pression (hPa)
    'observationTime',                     # 4  : timestamp
    'n2o_degree_of_freedom',               # 5  : degré de liberté
    'n2o_profile',                         # 6  : profil N2O (doublon)
    'n2o_profile_apriori',                 # 7  : profil a priori (ppmv)
    'n2o_profile_averaging_kernel_matrix', # 8  : matrice averaging kernel
    'n2o_profile_error',                   # 9  : erreur profil
    'n2o_profile_quality_flag',            # 10 : drapeau qualité
    'n2o_profile_uncert_matrix',           # 11 : matrice incertitude
    'n2o_degree_of_freedom',               # 12 : DOF (doublon)
    'IMC_StabilityFlag',                   # 13
    'interferogramQualityFlag',            # 14
    'missingFlag',                         # 15
    'soundingQualityFlag',                 # 16
    'spectrumQualityFlag'                  # 17
]

# --- 6. Datasets HDF4 FTIR ---
datasets_ftir = [
    'DATETIME',                                                    # 0
    'LATITUDE.INSTRUMENT',                                         # 1
    'LONGITUDE.INSTRUMENT',                                        # 2
    'ALTITUDE.INSTRUMENT',                                         # 3
    'SURFACE.PRESSURE_INDEPENDENT',                                # 4
    'SURFACE.TEMPERATURE_INDEPENDENT',                             # 5
    'ALTITUDE',                                                    # 6
    'ALTITUDE.BOUNDARIES',                                         # 7
    'PRESSURE_INDEPENDENT',                                        # 8
    'TEMPERATURE_INDEPENDENT',                                     # 9
    'N2O.MIXING.RATIO.VOLUME_ABSORPTION.SOLAR',                    # 10
    'N2O.MIXING.RATIO.VOLUME_ABSORPTION.SOLAR_APRIORI',            # 11
    'N2O.MIXING.RATIO.VOLUME_ABSORPTION.SOLAR_AVK',                # 12
    'INTEGRATION.TIME',                                            # 13
    'N2O.MIXING.RATIO.VOLUME_ABSORPTION.SOLAR_UNCERTAINTY.RANDOM.COVARIANCE',     # 14
    'N2O.MIXING.RATIO.VOLUME_ABSORPTION.SOLAR_UNCERTAINTY.SYSTEMATIC.COVARIANCE', # 15
    'N2O.COLUMN.PARTIAL_ABSORPTION.SOLAR',                         # 16
    'N2O.COLUMN.PARTIAL_ABSORPTION.SOLAR_APRIORI',                 # 17
    'N2O.COLUMN_ABSORPTION.SOLAR',                                 # 18
    'N2O.COLUMN_ABSORPTION.SOLAR_APRIORI',                         # 19
    'N2O.COLUMN_ABSORPTION.SOLAR_AVK',                             # 20
    'N2O.COLUMN_ABSORPTION.SOLAR_UNCERTAINTY.RANDOM.STANDARD',     # 21
    'N2O.COLUMN_ABSORPTION.SOLAR_UNCERTAINTY.SYSTEMATIC.STANDARD', # 22
    'ANGLE.SOLAR_ZENITH.ASTRONOMICAL',                             # 23
    'ANGLE.SOLAR_AZIMUTH',                                         # 24
    'H2O.MIXING.RATIO.VOLUME_ABSORPTION.SOLAR',                    # 25
    'H2O.COLUMN_ABSORPTION.SOLAR'                                  # 26
]

# --- 7. Stations retenues (nom : latitude °) ---
stations_retenues = {
    'Zugspitze': 47.4237,
    'Kiruna':    67.8382,
    'Izana':     28.2984,
    'Mauna Loa': 19.5400,
    'Tsukuba':   36.0500
}


# ================================================================================
# II. FONCTIONS UTILITAIRES
# ================================================================================

# --- 1. Accès fichiers GOSAT ---

def chemin_fichier_gosat(mois, jour):
    """Retourne le chemin du fichier GOSAT, ou None si inexistant."""
    chemin = (
        fr"C:\Users\gauti\OneDrive\Documents\Cours\PYTHON\REPORT\Data\gosat\2019"
        fr"\GOSAT2TFTS22019{mois:02d}{jour:02d}_R2TTGPV0106000009.h5"
    )
    return chemin if os.path.exists(chemin) else None

def afficher_cles_gosat(mois, jour):
    """Affiche les clés de chaque groupe GOSAT (debug)."""
    f = h5py.File(chemin_fichier_gosat(mois, jour), 'r')
    for i in range(7):
        print('Groupe', i, ':', list(f[groupes_gosat[i]].keys()))

def extraire_gosat(mois, jour, idx_groupe, idx_dataset):
    """Extrait un dataset d'un fichier GOSAT HDF5."""
    chemin = chemin_fichier_gosat(mois, jour)
    if chemin is None:
        return None
    with h5py.File(chemin, 'r') as f:
        return f[groupes_gosat[idx_groupe]][datasets_gosat[idx_dataset]][:]


# --- 2. Accès fichiers FTIR ---

def extraire_ftir(fichier_hdf, idx_dataset):
    """Extrait un dataset d'un fichier FTIR HDF4."""
    sds = fichier_hdf.select(datasets_ftir[idx_dataset])
    return sds.get()


# --- 3. Conversion temporelle ---

def convertir_temps_gosat(octets_temps):
    """Convertit un timestamp GOSAT (bytes) en datetime."""
    chaine = octets_temps.decode('utf-8')
    return datetime.datetime.strptime(chaine[:19], '%Y-%m-%dT%H:%M:%S')


# --- 4. Distance Haversine ---

def distance_haversine(lat_station, lon_station, lat_gosat, lon_gosat):
    """Distance orthodromique (km) entre station et pixel GOSAT."""
    lat1 = np.radians(lat_station)
    lon1 = np.radians(lon_station)
    lat2 = np.radians(lat_gosat)
    lon2 = np.radians(lon_gosat)
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = np.sin(dlat / 2)**2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon / 2)**2
    c = 2 * np.arctan(np.sqrt(a) / np.sqrt(1 - a))
    return 6371 * c  # km


# --- 5. Interpolation en log(pression) ---

def interpoler_profil(pression_cible, pression_source, profil_source):
    """Interpole un profil FTIR sur la grille de pression GOSAT."""
    return np.interp(np.log(pression_cible), np.log(pression_source), profil_source)


# --- 6. Estimation de Rodgers ---

def estimation_rodgers(matrice_avk, profil_apriori, profil_n2o):
    """x_hat = x_a + A * (x - x_a). Retourne le profil FTIR lissé."""
    difference = profil_n2o - profil_apriori
    return profil_apriori + matrice_avk @ difference


# ================================================================================
# III. CHARGEMENT DES DONNÉES FTIR
# ================================================================================

print("=" * 80)
print("CHARGEMENT DES DONNÉES FTIR")
print("=" * 80)

dates_ftir_par_fichier = []   # Dates (str) par fichier
coordonnees_stations = []     # [lat, lon] par fichier
profils_n2o_ftir = []         # Profils N2O (ppbv) par fichier
profils_apriori_ftir = []     # Profils a priori (ppbv) par fichier
matrices_avk_ftir = []        # Matrices AVK par fichier
pressions_ftir = []           # Niveaux pression (hPa) par fichier

for fichier in chemin_ftir:
    f = SD(fichier, SDC.READ)

    # Extraction dates et conversion
    temps_brut = extraire_ftir(f, 0)                 # Jours depuis 2000-01-01
    base_temps = datetime.datetime(2000, 1, 1)
    dates_converties = [base_temps + datetime.timedelta(days=float(t)) for t in temps_brut]
    dates_str = [d.strftime('%Y-%m-%d %H:%M:%S') for d in dates_converties]

    # Filtre année 2019
    if not dates_str[0].startswith('2019-'):
        continue

    dates_ftir_par_fichier.append(dates_str)

    # Coordonnées station (lat, lon en °)
    coordonnees_stations.append(np.array([
        extraire_ftir(f, 1)[0],
        extraire_ftir(f, 2)[0]
    ]))

    # Profils N2O, a priori, AVK, pression
    n2o = extraire_ftir(f, 10)       # Profil N2O
    apriori = extraire_ftir(f, 11)   # Profil a priori
    avk = extraire_ftir(f, 12)       # Matrice AVK
    pression = extraire_ftir(f, 8)   # Niveaux pression (hPa)

    # Conversion ppmv → ppbv si nécessaire
    for idx in range(len(n2o)):
        if n2o[idx][0] < 1e-3 or n2o[idx][-1] < 1e-3:
            n2o[idx] *= 1000
            apriori[idx] *= 1000

    # Réordonnement par pression croissante
    for idx in range(len(pression)):
        if pression[idx][0] > pression[idx][-1]:
            pression[idx] = pression[idx][::-1]
            n2o[idx] = n2o[idx][::-1]
            apriori[idx] = apriori[idx][::-1]
            avk[idx] = avk[idx][::-1, ::-1]

    # Filtrage valeurs aberrantes (> 340 ppbv → NaN)
    for idx in range(len(n2o)):
        masque_aberrant = n2o[idx] > 340
        n2o[idx][masque_aberrant] = np.nan
        apriori[idx][masque_aberrant] = np.nan
        avk[idx][masque_aberrant, :] = np.nan

    # Stockage
    profils_n2o_ftir.append(n2o)
    profils_apriori_ftir.append(apriori)
    matrices_avk_ftir.append(avk)
    pressions_ftir.append(pression)

coordonnees_stations = np.stack(coordonnees_stations)  # (n_fichiers, 2)


# ================================================================================
# IV. CHARGEMENT ET TRAITEMENT DES DONNÉES GOSAT-2
# ================================================================================

def charger_gosat_jour(mois, jour):
    """
    Charge et nettoie les données GOSAT-2 pour un jour donné.
    Retourne None si fichier inexistant ou vide.
    Retourne : (n2o, apriori, avk, pression, lat, lon, temps) en ppbv/hPa.
    """
    n2o = extraire_gosat(mois, jour, 3, 2)         # Profils N2O (ppmv)
    if n2o is None:
        return None
    apriori = extraire_gosat(mois, jour, 3, 7)      # A priori (ppmv)
    avk = extraire_gosat(mois, jour, 3, 8)          # Matrice AVK
    pression = extraire_gosat(mois, jour, 3, 3)     # Pression (hPa)
    drapeau = extraire_gosat(mois, jour, 3, 10)     # Drapeau qualité
    degre_liberte = extraire_gosat(mois, jour, 3, 5) # DOF
    latitudes = extraire_gosat(mois, jour, 6, 0)    # Latitudes (°)
    longitudes = extraire_gosat(mois, jour, 6, 1)   # Longitudes (°)
    temps = extraire_gosat(mois, jour, 5, 4)         # Timestamps
    if temps is None:
        return None

    # Conversion en float
    n2o = n2o.astype(float)
    apriori = apriori.astype(float)
    avk = avk.astype(float)
    pression = pression.astype(float)
    drapeau = drapeau.astype(float)
    degre_liberte = degre_liberte.astype(float)

    # Remplacement valeurs marqueur (-9.9e+36) par NaN
    invalide = n2o == -9.900000048566208e+36
    n2o[invalide] = np.nan
    pression[invalide] = np.nan
    apriori[invalide] = np.nan
    avk[invalide] = np.nan
    drapeau[drapeau == -1] = np.nan
    degre_liberte[degre_liberte == -9.900000048566208e+36] = np.nan

    if len(n2o) == 0:
        return None

    # Réordonnement par pression croissante
    for k in range(len(pression)):
        if pression[k][0] > pression[k][-1]:
            pression[k] = pression[k][::-1]
            n2o[k] = n2o[k][::-1]
            apriori[k] = apriori[k][::-1]
            avk[k] = avk[k][::-1, ::-1]

    # Conversion ppmv → ppbv
    n2o *= 1000
    apriori *= 1000

    # Zéros → NaN
    n2o[n2o == 0] = np.nan
    pression[pression == 0] = np.nan

    # Filtrage DOF < 1 (profil rejeté)
    masque_dof = (degre_liberte < 1.0) | (np.isnan(degre_liberte))
    n2o[masque_dof, :] = np.nan
    pression[masque_dof, :] = np.nan
    apriori[masque_dof, :] = np.nan
    avk[masque_dof, :, :] = np.nan
    latitudes[masque_dof] = np.nan
    longitudes[masque_dof] = np.nan

    # Suppression profils entièrement NaN
    indices_valides = ~np.all(np.isnan(n2o), axis=1)
    n2o = n2o[indices_valides]
    pression = pression[indices_valides]
    apriori = apriori[indices_valides]
    avk = avk[indices_valides]
    latitudes = latitudes[indices_valides]
    longitudes = longitudes[indices_valides]
    temps = temps[indices_valides]

    return n2o, apriori, avk, pression, latitudes, longitudes, temps


# ================================================================================
# V. COLOCALISATION ET ESTIMATION DE RODGERS
# ================================================================================

print("\n" + "=" * 80)
print("COLOCALISATION SPATIO-TEMPORELLE ET ESTIMATION DE RODGERS")
print("=" * 80)

resultats_par_station = {lat: [] for lat in stations_retenues.values()}  # Clé = latitude

# Boucle sur chaque fichier FTIR (une station par fichier)
for idx_fichier in range(len(dates_ftir_par_fichier)):
    lat_station, lon_station = coordonnees_stations[idx_fichier]
    nombre_profils_ftir = len(dates_ftir_par_fichier[idx_fichier])
    print(f"\nStation : [{lat_station:.2f}, {lon_station:.2f}]")

    # Boucle mois (mars=3 à décembre=12)
    for mois in range(3, 13):
        fichiers_du_mois = glob.glob(
            fr"C:\Users\gauti\OneDrive\Documents\Cours\PYTHON\REPORT\Data\gosat\2019"
            fr"\GOSAT2TFTS22019{mois:02d}*.h5"
        )
        print(f"  Mois de {noms_mois[mois-1]} : {len(fichiers_du_mois)} fichiers")

        # Boucle jours
        for jour in range(1, len(fichiers_du_mois) + 1):
            profils_ftir_jour = []      # FTIR interpolés (ppbv)
            profils_gosat_jour = []     # GOSAT mesurés (ppbv)
            pressions_gosat_jour = []   # Pressions GOSAT (hPa)
            pressions_ftir_jour = []    # Pressions FTIR interpolées (hPa)
            estimations_jour = []       # Estimations Rodgers (ppbv)

            # Chargement GOSAT du jour
            donnees_gosat = charger_gosat_jour(mois, jour)
            if donnees_gosat is None:
                continue
            n2o_gosat, apriori_gosat, avk_gosat, pression_gosat, \
                lat_gosat, lon_gosat, temps_gosat = donnees_gosat

            # Découpe atmosphère (niveaux 15 à 30)
            n2o_gosat = n2o_gosat[:, 15:]
            pression_gosat = pression_gosat[:, 15:]
            apriori_gosat = apriori_gosat[:, 15:]
            avk_gosat = avk_gosat[:, 15:, 15:]

            # Filtre spatial (Haversine)
            distances_km = distance_haversine(lat_station, lon_station, lat_gosat, lon_gosat)
            masque_spatial = distances_km < rayon_colocalisation_km
            if not np.any(masque_spatial):
                continue

            # Application masque spatial
            n2o_gosat = n2o_gosat[masque_spatial]
            apriori_gosat = apriori_gosat[masque_spatial]
            pression_gosat = pression_gosat[masque_spatial]
            avk_gosat = avk_gosat[masque_spatial]
            temps_gosat = temps_gosat[masque_spatial]

            # Filtre temporel (±24h) et estimation Rodgers
            for idx_ftir in range(nombre_profils_ftir):
                date_ftir = datetime.datetime.strptime(
                    dates_ftir_par_fichier[idx_fichier][idx_ftir], '%Y-%m-%d %H:%M:%S'
                )
                for k in range(len(temps_gosat)):
                    date_gosat = convertir_temps_gosat(temps_gosat[k])
                    if abs(date_ftir - date_gosat) > datetime.timedelta(hours=24):
                        continue
                    lat_arrondie = round(float(lat_station), 4)
                    lon_arrondie = round(float(lon_station), 4)
                    if lat_arrondie not in stations_retenues.values():
                        continue
                    # Interpolation FTIR sur grille GOSAT
                    n2o_ftir_brut = profils_n2o_ftir[idx_fichier][idx_ftir]
                    pression_ftir_brut = pressions_ftir[idx_fichier][idx_ftir]
                    n2o_ftir_interpole = interpoler_profil(pression_gosat[k], pression_ftir_brut, n2o_ftir_brut)
                    pression_ftir_interpolee = interpoler_profil(pression_gosat[k], pression_ftir_brut, pression_ftir_brut)
                    # Estimation Rodgers
                    profil_estime = estimation_rodgers(avk_gosat[k], apriori_gosat[k], n2o_ftir_interpole)
                    # Stockage jour
                    estimations_jour.append(profil_estime)
                    profils_ftir_jour.append(n2o_ftir_interpole)
                    profils_gosat_jour.append(n2o_gosat[k])
                    pressions_gosat_jour.append(pression_gosat[k])
                    pressions_ftir_jour.append(pression_ftir_interpolee)

            # Moyenne journalière et stockage
            if profils_ftir_jour:
                moy_ftir = np.nanmean(np.stack(profils_ftir_jour), axis=0)
                moy_gosat = np.nanmean(np.stack(profils_gosat_jour), axis=0)
                moy_pression_ftir = np.nanmean(np.stack(pressions_ftir_jour), axis=0)
                moy_pression_gosat = np.nanmean(np.stack(pressions_gosat_jour), axis=0)
                moy_estimation = np.nanmean(np.stack(estimations_jour), axis=0)
                if lat_arrondie != 78.9232 and lat_arrondie != 5.8059:
                    resultats_par_station[lat_arrondie].append({
                        "gosat":          moy_gosat,           # Profil GOSAT moyen (ppbv)
                        "ftir":           moy_ftir,            # Profil FTIR moyen (ppbv)
                        "estimation":     moy_estimation,      # Estimation Rodgers (ppbv)
                        "pression_ftir":  moy_pression_ftir,   # Pression FTIR (hPa)
                        "pression_gosat": moy_pression_gosat,  # Pression GOSAT (hPa)
                        "date_ftir":      date_ftir,           # Date FTIR
                        "date_gosat":     date_gosat,          # Date GOSAT
                        "mois_jour":      (mois, jour),        # (mois, jour)
                    })


# ================================================================================
# VI. STATISTIQUES PAR NIVEAU DE PRESSION
# ================================================================================

# --------------------------------------------------------------------------
# 1. PAR STATION (BIAIS, RMSE, CORRÉLATION)
# --------------------------------------------------------------------------

print("\n" + "=" * 80)
print("STATISTIQUES PAR NIVEAU DE PRESSION, PAR STATION")
print("=" * 80)

biais_par_station = {}   # {nom_station: array biais par niveau}
rmse_par_station = {}    # {nom_station: array RMSE par niveau}
corr_par_station = {}    # {nom_station: array corrélation par niveau}
pres_par_station = {}    # {nom_station: array pression moyenne par niveau}
stations_avec_donnees = []

for nom_station, lat_station in stations_retenues.items():
    donnees_station = resultats_par_station[lat_station]
    if not donnees_station:
        continue
    n_niveaux = len(donnees_station[0]['estimation'])  # Nombre niveaux pression
    biais_niv = np.full(n_niveaux, np.nan)   # Biais par niveau (ppbv)
    rmse_niv = np.full(n_niveaux, np.nan)    # RMSE par niveau (ppbv)
    corr_niv = np.full(n_niveaux, np.nan)    # Corrélation par niveau
    pres_niv = np.full(n_niveaux, np.nan)    # Pression moyenne par niveau (hPa)
    for p in range(n_niveaux):
        est = np.array([e['estimation'][p] for e in donnees_station])   # Estimations (ppbv)
        ftir = np.array([e['ftir'][p] for e in donnees_station])        # FTIR (ppbv)
        pres = np.array([e['pression_gosat'][p] for e in donnees_station]) # Pression (hPa)
        masque = ~np.isnan(est) & ~np.isnan(ftir)
        if np.sum(masque) < 2:
            continue
        diff = est[masque] - ftir[masque]          # Écarts estimation/FTIR (ppbv)
        biais_niv[p] = np.mean(diff)               # Biais = moyenne des écarts
        rmse_niv[p] = np.sqrt(np.mean(diff**2))    # RMSE = racine(moyenne(écarts²))
        corr_niv[p], _ = pearsonr(est[masque], ftir[masque])  # Corrélation Pearson
        pres_niv[p] = np.nanmean(pres)             # Pression moyenne (hPa)
    biais_par_station[nom_station] = biais_niv
    rmse_par_station[nom_station] = rmse_niv
    corr_par_station[nom_station] = corr_niv
    pres_par_station[nom_station] = pres_niv
    stations_avec_donnees.append(nom_station)

# --- Figure Biais par station ---
if stations_avec_donnees:
    n_stations = len(stations_avec_donnees)
    fig, axes = plt.subplots(1, n_stations, figsize=(18, 7), sharey=True)
    if n_stations == 1: axes = [axes]
    for i, nom_station in enumerate(stations_avec_donnees):
        ax = axes[i]
        ax.plot(biais_par_station[nom_station], pres_par_station[nom_station], 'o-', color='green', linewidth=2)
        ax.axvline(x=0, color='gray', linestyle='--', linewidth=0.8)
        ax.set_xlabel("Biais (ppbv)", fontweight='bold')
        if i == 0: ax.set_ylabel("Pression (hPa)", fontweight='bold')
        ax.set_title(f"{nom_station}", fontweight='bold')
        ax.invert_yaxis()
        ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.suptitle("Statistiques GOSAT vs FTIR par niveau de pression : Biais", y=1.02, fontweight='bold')
    plt.show()

    # --- Figure RMSE par station ---
    fig, axes = plt.subplots(1, n_stations, figsize=(18, 7), sharey=True)
    if n_stations == 1: axes = [axes]
    for i, nom_station in enumerate(stations_avec_donnees):
        ax = axes[i]
        ax.plot(rmse_par_station[nom_station], pres_par_station[nom_station], 'o-', color='blue', linewidth=2)
        ax.set_xlabel("RMSE (ppbv)", fontweight='bold')
        if i == 0: ax.set_ylabel("Pression (hPa)", fontweight='bold')
        ax.set_title(f"{nom_station}", fontweight='bold')
        ax.invert_yaxis()
        ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.suptitle("Statistiques GOSAT vs FTIR par niveau de pression : RMSE", y=1.02, fontweight='bold')
    plt.show()

    # --- Figure Corrélation par station ---
    fig, axes = plt.subplots(1, n_stations, figsize=(18, 7), sharey=True)
    if n_stations == 1: axes = [axes]
    for i, nom_station in enumerate(stations_avec_donnees):
        ax = axes[i]
        ax.plot(corr_par_station[nom_station], pres_par_station[nom_station], 'o-', color='red', linewidth=2)
        ax.axvline(x=1, color='gray', linestyle='--', linewidth=0.8)
        ax.set_xlabel("Corrélation de pearsonr (R)", fontweight='bold')
        if i == 0: ax.set_ylabel("Pression (hPa)", fontweight='bold')
        ax.set_title(f"{nom_station}", fontweight='bold')
        ax.set_xlim(-0.5, 1.1)
        ax.invert_yaxis()
        ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.suptitle("Statistiques GOSAT vs FTIR par niveau de pression : Corrélation", y=1.02, fontweight='bold')
    plt.show()


# --------------------------------------------------------------------------
# 2. GLOBALEMENT (BIAIS, RMSE, CORRÉLATION)
# --------------------------------------------------------------------------

print("\n" + "=" * 80)
print("CALCUL DES STATISTIQUES PAR NIVEAU DE PRESSION")
print("=" * 80)

n_niveaux = len(list(resultats_par_station.values())[0][0]['estimation'])
biais_par_niveau = np.full(n_niveaux, np.nan)    # Biais global par niveau (ppbv)
rmse_par_niveau = np.full(n_niveaux, np.nan)     # RMSE global par niveau (ppbv)
corr_par_niveau = np.full(n_niveaux, np.nan)     # Corrélation globale par niveau
pression_moyenne = np.full(n_niveaux, np.nan)    # Pression moyenne par niveau (hPa)

for p in range(n_niveaux):
    toutes_estimations = []  # Toutes les estimations au niveau p (ppbv)
    toutes_ftir = []         # Tous les FTIR au niveau p (ppbv)
    toutes_pressions = []    # Toutes les pressions au niveau p (hPa)
    for lat_station in resultats_par_station.values():
        for entree in lat_station:
            toutes_estimations.append(entree['estimation'][p])
            toutes_ftir.append(entree['ftir'][p])
            toutes_pressions.append(entree['pression_gosat'][p])
    est = np.array(toutes_estimations)
    ftir = np.array(toutes_ftir)
    pres = np.array(toutes_pressions)
    masque = ~np.isnan(est) & ~np.isnan(ftir)
    if np.sum(masque) < 2:
        continue
    diff = est[masque] - ftir[masque]
    biais_par_niveau[p] = np.mean(diff)
    rmse_par_niveau[p] = np.sqrt(np.mean(diff**2))
    corr_par_niveau[p], _ = pearsonr(est[masque], ftir[masque])
    pression_moyenne[p] = np.nanmean(pres)

# Tableau récapitulatif
print("Niveau | Pression (hPa) | Biais (ppbv) | RMSE (ppbv) | Corrélation")
print("-" * 75)
for p in range(n_niveaux):
    print(f"  {p:2d}   |   {pression_moyenne[p]:8.1f}     |   {biais_par_niveau[p]:+7.3f}    |   {rmse_par_niveau[p]:7.3f}    |   {corr_par_niveau[p]:6.3f}")

# --- 3 graphes globaux ---
fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(18, 7), sharey=True)

ax1.plot(biais_par_niveau, pression_moyenne, 'o-', color='black', linewidth=2)
ax1.axvline(x=0, color='gray', linestyle='--', linewidth=0.8)
ax1.set_xlabel("Biais (ppbv)", fontweight='bold')
ax1.set_ylabel("Pression (hPa)", fontweight='bold')
ax1.set_title("Biais par niveau de pression", fontweight='bold')
ax1.invert_yaxis()
ax1.grid(True, alpha=0.3)

ax2.plot(rmse_par_niveau, pression_moyenne, 'o-', color='darkorange', linewidth=2)
ax2.set_xlabel("RMSE (ppbv)", fontweight='bold')
ax2.set_title("RMSE par niveau de pression", fontweight='bold')
ax2.invert_yaxis()
ax2.grid(True, alpha=0.3)

ax3.plot(corr_par_niveau, pression_moyenne, 'o-', color='darkorchid', linewidth=2)
ax3.axvline(x=1, color='gray', linestyle='--', linewidth=0.8)
ax3.set_xlabel("Corrélation de pearsonr (R)", fontweight='bold')
ax3.set_title("Corrélation par niveau de pression", fontweight='bold')
ax3.set_xlim(-0.5, 1.1)
ax3.invert_yaxis()
ax3.grid(True, alpha=0.3)

plt.tight_layout()
plt.suptitle("Statistiques GOSAT vs FTIR par niveau de pression (toutes stations)", y=1.02, fontweight='bold')
plt.show()


# ================================================================================
# VII. VISUALISATION GRAPHIQUE
# ================================================================================

# --------------------------------------------------------------------------
# 1. PROFILS VERTICAUX : ESTIMATION RODGERS VS FTIR PAR STATION
# --------------------------------------------------------------------------

print("\n" + "=" * 80)
print("PROFILS VERTICAUX PAR STATION")
print("=" * 80)

nombre_stations = len(stations_retenues)
nombre_colonnes = 3
nombre_lignes = (nombre_stations + nombre_colonnes - 1) // nombre_colonnes

fig, axes = plt.subplots(nombre_lignes, nombre_colonnes, figsize=(15, nombre_lignes * 5), sharey=True)
axes = axes.flatten()

for j, (nom_station, lat_station) in enumerate(stations_retenues.items()):
    liste_estimations = []   # Profils estimés (ppbv)
    liste_pressions = []     # Pressions GOSAT (hPa)
    liste_ftir = []          # Profils FTIR (ppbv)
    for entree in resultats_par_station[lat_station]:
        liste_estimations.append(entree['estimation'])
        liste_pressions.append(entree['pression_gosat'])
        liste_ftir.append(entree['ftir'])
    moy_estimation = np.nanmean(np.stack(liste_estimations), axis=0)  # Moyenne annuelle (ppbv)
    moy_pression = np.nanmean(np.stack(liste_pressions), axis=0)     # Pression moyenne (hPa)
    moy_ftir = np.nanmean(np.stack(liste_ftir), axis=0)              # Moyenne FTIR (ppbv)
    std_estimation = np.nanstd(np.stack(liste_estimations), axis=0)   # Écart-type estimation (ppbv)
    std_ftir = np.nanstd(np.stack(liste_ftir), axis=0)               # Écart-type FTIR (ppbv)
    ax = axes[j]
    ax.errorbar(moy_estimation, moy_pression, xerr=std_estimation, color='red', fmt='-', capsize=2, label='GOSAT (Rodgers)')
    ax.errorbar(moy_ftir, moy_pression, xerr=std_ftir, color='blue', fmt='-', capsize=2, label='FTIR (référence)')
    ax.invert_yaxis()
    ax.grid(True, alpha=0.3)
    ax.set_title(f"Profil vertical : {nom_station}", fontweight='bold')
    ax.set_xlabel("N$_2$O (ppbv)")
    if j % nombre_colonnes == 0: ax.set_ylabel("Pression (hPa)")
    ax.legend(fontsize='small')
    ax.set_xlim(300, 340)

for k in range(j + 1, len(axes)): axes[k].axis('off')
plt.tight_layout()
plt.show()


# --------------------------------------------------------------------------
# 2. ÉVOLUTION MENSUELLE PAR STATION (NIVEAU ~600 hPa, INDEX 9)
# --------------------------------------------------------------------------

print("\n" + "=" * 80)
print("ÉVOLUTION MENSUELLE PAR STATION (NIVEAU INDEX 9, ~600 hPa)")
print("=" * 80)

idx_niveau = 9      # Index ~600 hPa
mois_axes = list(range(3, 13))

fig, axes_all = plt.subplots(3, 2, figsize=(14, 12))
axes_all = axes_all.flatten()

for i, (nom_station, lat_station) in enumerate(stations_retenues.items()):
    moyennes_estimation = []  # Moyennes mensuelles estimation (ppbv)
    moyennes_ftir = []        # Moyennes mensuelles FTIR (ppbv)
    std_estimation = []       # Écarts-types mensuels estimation (ppbv)
    std_ftir = []             # Écarts-types mensuels FTIR (ppbv)
    biais_mensuel = []        # Biais mensuel (ppbv)

    for m in mois_axes:
        val_estimation = [e['estimation'][idx_niveau] for e in resultats_par_station[lat_station] if e['mois_jour'][0] == m]
        val_ftir = [e['ftir'][idx_niveau] for e in resultats_par_station[lat_station] if e['mois_jour'][0] == m]
        moy_est = np.mean(val_estimation) if val_estimation else np.nan
        moy_ft = np.mean(val_ftir) if val_ftir else np.nan
        moyennes_estimation.append(moy_est)
        moyennes_ftir.append(moy_ft)
        std_estimation.append(np.std(val_estimation) if len(val_estimation) > 1 else 0)
        std_ftir.append(np.std(val_ftir) if len(val_ftir) > 1 else 0)
        if val_estimation and val_ftir:
            n_min = min(len(val_estimation), len(val_ftir))
            biais = np.mean([val_estimation[k] - val_ftir[k] for k in range(n_min)])
            biais_mensuel.append(biais)
        else:
            biais_mensuel.append(np.nan)

    moy_est_arr = np.array(moyennes_estimation)
    moy_ft_arr = np.array(moyennes_ftir)
    std_est_arr = np.array(std_estimation)
    std_ft_arr = np.array(std_ftir)
    biais_arr = np.array(biais_mensuel)
    mois_arr = np.array(mois_axes)
    masque_est = ~np.isnan(moy_est_arr)
    masque_ft = ~np.isnan(moy_ft_arr)
    masque_biais = ~np.isnan(biais_arr)

    ax = axes_all[i]
    # Courbes moyennes avec écarts-types
    ax.errorbar(mois_arr[masque_est], moy_est_arr[masque_est], yerr=std_est_arr[masque_est],
                color='red', fmt='-o', capsize=3, capthick=1, label='GOSAT (Rodgers) ± σ')
    ax.errorbar(mois_arr[masque_ft], moy_ft_arr[masque_ft], yerr=std_ft_arr[masque_ft],
                color='blue', fmt='-o', capsize=3, capthick=1, label='FTIR (référence) ± σ')

    # Biais sur axe secondaire (centré en 0)
    ax2 = ax.twinx()
    max_abs = np.nanmax(np.abs(biais_arr[masque_biais])) if np.any(masque_biais) else 1.0
    ylim_margin = max_abs * 1.2 if max_abs > 0 else 1.0
    ax2.bar(mois_arr[masque_biais], biais_arr[masque_biais], width=0.5, color='pink', alpha=0.6, label='Biais (ppbv)')
    ax2.set_ylim(-ylim_margin, ylim_margin)
    ax2.set_ylabel("Biais (ppbv)", color='hotpink')
    ax2.tick_params(axis='y', labelcolor='hotpink')

    ax.set_title(f"Station : {nom_station}", fontweight='bold')
    ax.set_xticks(mois_axes)
    ax.set_ylabel("N$_2$O (ppbv)")
    ax.grid(True, alpha=0.3)
    if i == 0:
        handles1, labels1 = ax.get_legend_handles_labels()
        handles2, labels2 = ax2.get_legend_handles_labels()
        ax.legend(handles1 + handles2, labels1 + labels2, fontsize='x-small', loc='upper left')

for k in range(i + 1, len(axes_all)): axes_all[k].axis('off')
plt.tight_layout()
plt.suptitle("Évolution mensuelle du N$_2$O (niveau ~600 hPa)", y=1.02, fontweight='bold')
plt.show()


# --------------------------------------------------------------------------
# 3. ÉVOLUTION MENSUELLE PAR STATION (NIVEAU ~300 hPa, INDEX 5)
# --------------------------------------------------------------------------

print("\n" + "=" * 80)
print("ÉVOLUTION MENSUELLE PAR STATION (NIVEAU INDEX 5, ~300 hPa)")
print("=" * 80)

idx_niveau = 5      # Index ~300 hPa

fig, axes_all = plt.subplots(3, 2, figsize=(14, 12))
axes_all = axes_all.flatten()

for i, (nom_station, lat_station) in enumerate(stations_retenues.items()):
    moyennes_estimation = []
    moyennes_ftir = []
    std_estimation = []
    std_ftir = []
    biais_mensuel = []
    for m in mois_axes:
        val_estimation = [e['estimation'][idx_niveau] for e in resultats_par_station[lat_station] if e['mois_jour'][0] == m]
        val_ftir = [e['ftir'][idx_niveau] for e in resultats_par_station[lat_station] if e['mois_jour'][0] == m]
        moy_est = np.mean(val_estimation) if val_estimation else np.nan
        moy_ft = np.mean(val_ftir) if val_ftir else np.nan
        moyennes_estimation.append(moy_est)
        moyennes_ftir.append(moy_ft)
        std_estimation.append(np.std(val_estimation) if len(val_estimation) > 1 else 0)
        std_ftir.append(np.std(val_ftir) if len(val_ftir) > 1 else 0)
        if val_estimation and val_ftir:
            n_min = min(len(val_estimation), len(val_ftir))
            biais = np.mean([val_estimation[k] - val_ftir[k] for k in range(n_min)])
            biais_mensuel.append(biais)
        else:
            biais_mensuel.append(np.nan)
    moy_est_arr = np.array(moyennes_estimation)
    moy_ft_arr = np.array(moyennes_ftir)
    std_est_arr = np.array(std_estimation)
    std_ft_arr = np.array(std_ftir)
    biais_arr = np.array(biais_mensuel)
    mois_arr = np.array(mois_axes)
    toutes_valeurs = np.concatenate([moy_est_arr[~np.isnan(moy_est_arr)], moy_ft_arr[~np.isnan(moy_ft_arr)]])
    min_tot = np.min(toutes_valeurs) if toutes_valeurs.size else np.nan
    max_tot = np.max(toutes_valeurs) if toutes_valeurs.size else np.nan
    masque_est = ~np.isnan(moy_est_arr)
    masque_ft = ~np.isnan(moy_ft_arr)
    masque_biais = ~np.isnan(biais_arr)

    ax = axes_all[i]
    ax.errorbar(mois_arr[masque_est], moy_est_arr[masque_est], yerr=std_est_arr[masque_est],
                color='red', fmt='-o', capsize=3, capthick=1, label='GOSAT (Rodgers) ± σ')
    ax.errorbar(mois_arr[masque_ft], moy_ft_arr[masque_ft], yerr=std_ft_arr[masque_ft],
                color='blue', fmt='-o', capsize=3, capthick=1, label='FTIR (référence) ± σ')
    # Biais sur axe secondaire
    ax2 = ax.twinx()
    max_abs = np.nanmax(np.abs(biais_arr[masque_biais])) if np.any(masque_biais) else 1.0
    ylim_margin = max_abs * 1.2 if max_abs > 0 else 1.0
    ax2.bar(mois_arr[masque_biais], biais_arr[masque_biais], width=0.5, color='pink', alpha=0.6, label='Biais (ppbv)')
    ax2.set_ylim(-ylim_margin, ylim_margin)
    ax2.set_ylabel("Biais (ppbv)", color='hotpink')
    ax2.tick_params(axis='y', labelcolor='hotpink')
    ax.set_title(f"Station : {nom_station}", fontweight='bold')
    ax.set_xticks(mois_axes)
    ax.set_ylabel("N$_2$O (ppbv)")
    ax.grid(True, alpha=0.3)
    if i == 0:
        handles1, labels1 = ax.get_legend_handles_labels()
        handles2, labels2 = ax2.get_legend_handles_labels()
        ax.legend(handles1 + handles2, labels1 + labels2, fontsize='x-small', loc='upper left')

for k in range(i + 1, len(axes_all)): axes_all[k].axis('off')
plt.tight_layout()
plt.suptitle("Évolution mensuelle du N$_2$O (niveau ~300 hPa)", y=1.02, fontweight='bold')
plt.show()


# --------------------------------------------------------------------------
# 4. CORRÉLATION FTIR VS GOSAT PAR STATION (NUAGE DE POINTS)
# --------------------------------------------------------------------------

print("\n" + "=" * 80)
print("CORRÉLATION FTIR VS GOSAT PAR STATION")
print("=" * 80)

fig, axes = plt.subplots(nombre_lignes, nombre_colonnes, figsize=(15, nombre_lignes * 5))
axes = axes.flatten()

for j, (nom_station, lat_station) in enumerate(stations_retenues.items()):
    liste_estimations = [e['estimation'] for e in resultats_par_station[lat_station]]
    liste_ftir = [e['ftir'] for e in resultats_par_station[lat_station]]
    valeurs_estimation = np.stack(liste_estimations).flatten()  # Toutes estimations (ppbv)
    valeurs_ftir = np.stack(liste_ftir).flatten()               # Tous FTIR (ppbv)
    ax = axes[j]
    masque_valide = ~np.isnan(valeurs_ftir) & ~np.isnan(valeurs_estimation)
    if np.any(masque_valide):
        coeff_pearsonr, _ = pearsonr(valeurs_ftir[masque_valide], valeurs_estimation[masque_valide])
        ax.scatter(valeurs_ftir[masque_valide], valeurs_estimation[masque_valide], alpha=0.5, s=10, color='darkorchid')
        x_line = np.array([300, 345])
        ax.plot(x_line, x_line, 'k--', alpha=0.7, label='1:1')
        ax.plot(x_line, coeff_pearsonr * x_line + (1 - coeff_pearsonr) * 300, 'r--', alpha=0.7,
                label=f'y = {coeff_pearsonr:.2f}·x')
        ax.set_xlim(x_line)
        y_min = min(x_line.min(), (coeff_pearsonr * x_line).min(), np.nanmin(valeurs_estimation[masque_valide]))
        y_max = max(x_line.max(), (coeff_pearsonr * x_line).max(), np.nanmax(valeurs_estimation[masque_valide]))
        ax.set_ylim([y_min, y_max])
        ax.text(0.05, 0.9, f"R = {coeff_pearsonr:.2f}", transform=ax.transAxes, fontweight='bold',
                bbox=dict(facecolor='white', alpha=0.8))
    ax.grid(True, alpha=0.3)
    ax.set_title(f"Corrélation : {nom_station}", fontweight='bold')
    ax.set_xlabel("FTIR (ppbv)")
    ax.set_ylabel("GOSAT (ppbv)")

for k in range(j + 1, len(axes)): axes[k].axis('off')
plt.tight_layout()
plt.show()