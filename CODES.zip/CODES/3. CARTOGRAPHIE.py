# ================================================================================
#              CODE CARTOGRAPHIE : VALIDATION N2O GOSAT-2 VS FTIR
# ================================================================================
# Génération des cartes de répartition spatiale et temporelle des mesures
# de concentration en N2O du satellite GOSAT-2, et cartes de colocalisation
# avec les stations FTIR du réseau NDACC
# Période : mars à décembre 2019
# ================================================================================


import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from pyhdf.SD import SD, SDC
import h5py
import glob
import datetime
import pandas as pd
import os


# ================================================================================
# I. CONFIGURATION ET PARAMÈTRES
# ================================================================================

# --- 1. Chemins vers les données ---

chemin_ftir = r"C:\Users\gauti\OneDrive\Documents\Cours\PYTHON\REPORT\Data\ftir\2019"       # Fichiers FTIR (HDF4)
chemin_gosat_base = r"C:\Users\gauti\OneDrive\Documents\Cours\PYTHON\REPORT\Data\gosat\2019" # Fichiers GOSAT (HDF5)
chemin_sortie = r"C:\Users\gauti\OneDrive\Documents\Cours\PYTHON\REPORT\Data"                # Répertoire de sortie


# --- 2. Paramètres ---

rayon_colocalisation_km = 10 * 111  # Rayon colocalisation (km), ~10° latitude
niveau_pression = 6                  # Indice du niveau de pression analysé


# --- 3. Noms des mois ---

noms_mois = ["mars", "avril", "mai", "juin", "juillet",
             "août", "septembre", "octobre", "novembre", "décembre"]


# --- 4. Groupes HDF5 GOSAT-2 ---

groupes_gosat = [
    'CloudInformation',    # 0
    'L1QualityInfo',       # 1
    'Metadata',            # 2
    'RetrievalResult',     # 3
    'SceneAttribute',      # 4
    'SoundingAttribute',   # 5
    'SoundingGeometry'     # 6
]


# --- 5. Datasets HDF5 GOSAT-2 ---

datasets_gosat = [
    'latitude',                    # 0 : latitude pixel (°)
    'longitude',                   # 1 : longitude pixel (°)
    'n2o_profile',                 # 2 : profil N2O (ppmv)
    'pressure_level_profile_CH4',  # 3 : niveaux pression (hPa)
    'observationTime'              # 4 : timestamp mesure
]


# --- 6. Datasets HDF4 FTIR ---

datasets_ftir = [
    'DATETIME',                                                 # 0  : date mesure
    'LATITUDE.INSTRUMENT',                                      # 1  : latitude station (°)
    'LONGITUDE.INSTRUMENT',                                     # 2  : longitude station (°)
    'ALTITUDE.INSTRUMENT',                                      # 3  : altitude station (m)
    'SURFACE.PRESSURE_INDEPENDENT',                             # 4  : pression surface (hPa)
    'SURFACE.TEMPERATURE_INDEPENDENT',                          # 5  : température surface (K)
    'ALTITUDE',                                                 # 6  : grille altitudes (m)
    'ALTITUDE.BOUNDARIES',                                      # 7  : limites altitudes (m)
    'PRESSURE_INDEPENDENT',                                     # 8  : profil pression (hPa)
    'TEMPERATURE_INDEPENDENT',                                  # 9  : profil température (K)
    'N2O.MIXING.RATIO.VOLUME_ABSORPTION.SOLAR',                 # 10 : profil N2O mesuré
    'N2O.MIXING.RATIO.VOLUME_ABSORPTION.SOLAR_APRIORI',         # 11 : profil N2O a priori
    'N2O.MIXING.RATIO.VOLUME_ABSORPTION.SOLAR_AVK',             # 12 : matrice averaging kernel
]


# --- 7. Dictionnaire des stations FTIR ---

stations_ftir = {
    'Alesund (Norvège)':      [78.92, 11.92],
    'Paramaribo (Suriname)':  [5.81, -55.21],
    'Bremen (Allemagne)':     [53.10, 8.85],
    'Zugspitze (Allemagne)':  [47.42, 10.98],
    'Kiruna (Suède)':         [67.84, 20.40],
    'Izana (Espagne)':        [28.30, -16.48],
    'Mauna Loa (Hawaï)':      [19.54, -155.57],
    'Tsukuba (Japon)':        [36.05, 140.12]
}


# ================================================================================
# II. FONCTIONS D'EXTRACTION ET UTILITAIRES
# ================================================================================

def extraire_donnees_gosat(fichier_h5, groupe_idx, dataset_idx):
    """Extrait un dataset d'un fichier GOSAT HDF5."""
    groupe = groupes_gosat[groupe_idx]
    dataset = datasets_gosat[dataset_idx]
    return fichier_h5[groupe][dataset][:]


def extraire_donnees_ftir(fichier_hdf, dataset_idx):
    """Extrait un dataset d'un fichier FTIR HDF4 (première ligne)."""
    nom_dataset = datasets_ftir[dataset_idx]
    sds_obj = fichier_hdf.select(nom_dataset)
    data = sds_obj.get()
    return data[0]


def identifier_station(latitude, longitude):
    """Identifie le nom d'une station FTIR à partir de ses coordonnées."""
    lat_arrondie = round(float(latitude), 2)
    lon_arrondie = round(float(longitude), 2)
    for nom_station, coords in stations_ftir.items():
        if (round(coords[0], 2) == lat_arrondie and
            round(coords[1], 2) == lon_arrondie):
            return nom_station
    return 'Station inconnue'


def generer_cercle(rayon_km, longitude_centre, latitude_centre):
    """Génère un cercle géodésique (Haversine inverse) pour affichage."""
    R = 6371  # Rayon Terre (km)
    lat_rad = np.radians(latitude_centre)
    lon_rad = np.radians(longitude_centre)
    bearings = np.linspace(0, 2 * np.pi, 500)  # 500 points sur le cercle
    lats, lons = [], []
    for bearing in bearings:
        lat2 = np.arcsin(
            np.sin(lat_rad) * np.cos(rayon_km / R) +
            np.cos(lat_rad) * np.sin(rayon_km / R) * np.cos(bearing)
        )
        lon2 = lon_rad + np.arctan2(
            np.sin(bearing) * np.sin(rayon_km / R) * np.cos(lat_rad),
            np.cos(rayon_km / R) - np.sin(lat_rad) * np.sin(lat2)
        )
        lats.append(np.degrees(lat2))
        lons.append(np.degrees(lon2))
    return np.array(lons), np.array(lats)


def distance_haversine(lat1, lon1, lat2, lon2):
    """Distance orthodromique entre deux points (km), formule de Haversine."""
    R = 6371
    dlat = np.radians(lat2 - lat1)
    dlon = np.radians(lon2 - lon1)
    a = np.sin(dlat / 2)**2 + np.cos(np.radians(lat1)) * np.cos(np.radians(lat2)) * np.sin(dlon / 2)**2
    return 2 * R * np.arcsin(np.sqrt(a))


# ================================================================================
# III. CHARGEMENT DES DONNÉES FTIR
# ================================================================================

print("=" * 80)
print("CHARGEMENT DES DONNÉES FTIR")
print("=" * 80)

# --- 1. Listing des fichiers ---
fichiers_ftir = glob.glob(os.path.join(chemin_ftir, "*.hdf"))
print(f"Nombre de fichiers FTIR trouvés: {len(fichiers_ftir)}")

# --- 2. Extraction coordonnées stations ---
coordonnees_stations = []  # [lat, lon] par station
for fichier in fichiers_ftir:
    f_ftir = SD(fichier, SDC.READ)
    lat_station = extraire_donnees_ftir(f_ftir, 1)  # Latitude (°)
    lon_station = extraire_donnees_ftir(f_ftir, 2)  # Longitude (°)
    coordonnees_stations.append([lat_station, lon_station])
    f_ftir.end()
coordonnees_stations = np.unique(np.array(coordonnees_stations), axis=0)  # Suppression doublons
print(f"Nombre de stations : {len(coordonnees_stations)}")

# --- 3. Extraction mois FTIR disponibles ---
mois_ftir_disponibles = []  # Format 'YYYY-MM'
for fichier in fichiers_ftir:
    f_ftir = SD(fichier, SDC.READ)
    nom_dataset = datasets_ftir[0]
    sds_obj = f_ftir.select(nom_dataset)
    temps_ftir_array = sds_obj.get()  # Jours depuis 2000-01-01
    for temps in temps_ftir_array:
        date_ftir = datetime.datetime(2000, 1, 1) + datetime.timedelta(days=float(temps))
        mois_str = date_ftir.strftime('%Y-%m')
        if mois_str not in mois_ftir_disponibles:
            mois_ftir_disponibles.append(mois_str)
    f_ftir.end()


# ================================================================================
# IV. VISUALISATION GOSAT SANS FILTRE (GLOBAL)
# ================================================================================

print("\n" + "=" * 80)
print("TRAITEMENT GOSAT SANS FILTRE SPATIAL/TEMPOREL")
print("=" * 80)

# --- 1. Chargement données GOSAT 2019 ---
donnees_gosat_globales = []  # Liste {Date, Latitude, Longitude, N2O}
for num_mois in range(3, 13):
    fichiers_gosat_mois = glob.glob(
        os.path.join(chemin_gosat_base, f"GOSAT2TFTS22019{num_mois:02d}*.h5")
    )
    for fichier_gosat in fichiers_gosat_mois:
        f_gosat = h5py.File(fichier_gosat, 'r')
        latitudes_gosat = extraire_donnees_gosat(f_gosat, 6, 0)   # Latitudes (°)
        longitudes_gosat = extraire_donnees_gosat(f_gosat, 6, 1)  # Longitudes (°)
        profils_n2o = extraire_donnees_gosat(f_gosat, 3, 2)       # Profils N2O (ppmv)
        timestamps_gosat = extraire_donnees_gosat(f_gosat, 5, 4)  # Timestamps
        nombre_pixels = latitudes_gosat.shape[0]   # Nombre de pixels
        nombre_niveaux = profils_n2o.shape[1]      # 30 niveaux pression
        # Nettoyage : filtre [323, 334] ppbv après conversion ppmv→ppbv
        profils_n2o_nettoyes = np.full((nombre_pixels, nombre_niveaux), np.nan)
        for i in range(nombre_pixels):
            for k in range(nombre_niveaux):
                if 0.323 <= profils_n2o[i, k] <= 0.334:
                    profils_n2o_nettoyes[i, k] = profils_n2o[i, k] * 1000  # ppmv→ppbv
        # Stockage mesures valides
        for idx_pixel in range(nombre_pixels):
            date_gosat = datetime.datetime.fromisoformat(timestamps_gosat[idx_pixel].decode())
            mois_gosat = date_gosat.strftime('%Y-%m')
            concentration = profils_n2o_nettoyes[idx_pixel, niveau_pression]  # N2O (ppbv)
            if not np.isnan(concentration):
                donnees_gosat_globales.append({
                    'Date': mois_gosat,
                    'Latitude': latitudes_gosat[idx_pixel],
                    'Longitude': longitudes_gosat[idx_pixel],
                    'N2O': concentration
                })
        f_gosat.close()

df_gosat_global = pd.DataFrame(donnees_gosat_globales)  # DataFrame global
print(f"Données GOSAT globales chargées: {len(df_gosat_global)} mesures")


# --- 2. Cartes mensuelles SANS FILTRE ---

print("\n" + "=" * 80)
print("GÉNÉRATION DES CARTES MENSUELLES SANS FILTRE")
print("=" * 80)

for num_mois in range(3, 13):
    mois_str = f"2019-{num_mois:02d}"
    donnees_mois = df_gosat_global[df_gosat_global['Date'] == mois_str]  # Filtre mensuel
    if len(donnees_mois) == 0:
        print(f"  Aucune donnée pour {noms_mois[num_mois-3]}")
        continue
    fig = plt.figure(figsize=(14, 7))
    projection_carte = ccrs.PlateCarree()
    ax = plt.axes(projection=projection_carte)
    ax.set_global()
    ax.add_feature(cfeature.OCEAN, facecolor='dodgerblue')
    ax.add_feature(cfeature.LAND, facecolor='wheat')
    ax.add_feature(cfeature.LAKES, facecolor='deepskyblue')
    ax.add_feature(cfeature.RIVERS, linewidth=0.5, edgecolor='blue')
    ax.coastlines(linewidth=0.5, color='black', resolution='110m')
    gl = ax.gridlines(draw_labels=True, linewidth=0.3, color='gray', alpha=0.5)
    gl.top_labels = False
    gl.right_labels = False
    scatter = ax.scatter(
        donnees_mois['Longitude'], donnees_mois['Latitude'],
        c=donnees_mois['N2O'], cmap='coolwarm', s=1, alpha=0.8,
        transform=projection_carte
    )
    cbar = plt.colorbar(scatter, ax=ax, orientation='horizontal', pad=0.05, aspect=50)
    cbar.set_label('Concentration N₂O (ppb)', fontsize=11, fontweight='bold')
    plt.title(f"Points mesures concentration N₂O (niveau {niveau_pression}) - {noms_mois[num_mois-3].upper()} 2019 - GLOBAL",
              fontsize=14, fontweight='bold', pad=20)
    plt.xlabel('Longitude', fontsize=11)
    plt.ylabel('Latitude', fontsize=11)
    plt.tight_layout()
    plt.show()


# ================================================================================
# V. ANALYSE DE VARIABILITÉ SPATIALE
# ================================================================================

print("\n" + "=" * 80)
print("ANALYSE DE VARIABILITÉ SPATIALE DES DONNÉES GOSAT")
print("=" * 80)

# --- Grille globale ---
lat_min, lat_max, lat_step = -90, 90, 4    # Pas 4° latitude
lon_min, lon_max, lon_step = -180, 180, 4  # Pas 4° longitude
latitudes_grille = np.arange(lat_min, lat_max, lat_step)
longitudes_grille = np.arange(lon_min, lon_max, lon_step)
n_lat = len(latitudes_grille)  # Nombre cellules latitude
n_lon = len(longitudes_grille)  # Nombre cellules longitude
seuil_mesures = 8  # Seuil minimum mesures par cellule

# --- Matrices d'accumulation ---
nb_mesures = np.zeros((n_lat, n_lon))       # Nombre mesures par cellule
somme_n2o = np.zeros((n_lat, n_lon))        # Somme concentrations (ppbv)
somme_n2o_carre = np.zeros((n_lat, n_lon))  # Somme concentrations² (ppbv²)

# --- Boucle tous les mois ---
for num_mois in range(3, 13):
    fichiers_gosat_mois = glob.glob(
        os.path.join(chemin_gosat_base, f"GOSAT2TFTS22019{num_mois:02d}*.h5")
    )
    for fichier_gosat in fichiers_gosat_mois:
        f_gosat = h5py.File(fichier_gosat, 'r')
        latitudes_gosat = extraire_donnees_gosat(f_gosat, 6, 0)
        longitudes_gosat = extraire_donnees_gosat(f_gosat, 6, 1)
        profils_n2o = extraire_donnees_gosat(f_gosat, 3, 2)
        nombre_pixels = latitudes_gosat.shape[0]
        nombre_niveaux = profils_n2o.shape[1]
        # Nettoyage
        profils_n2o_nettoyes = np.full((nombre_pixels, nombre_niveaux), np.nan)
        for i in range(nombre_pixels):
            for k in range(nombre_niveaux):
                if 0.323 <= profils_n2o[i, k] <= 0.334:
                    profils_n2o_nettoyes[i, k] = profils_n2o[i, k] * 1000
        # Attribution aux cellules
        for idx_pixel in range(nombre_pixels):
            lat = latitudes_gosat[idx_pixel]   # Latitude pixel (°)
            lon = longitudes_gosat[idx_pixel]   # Longitude pixel (°)
            concentration = profils_n2o_nettoyes[idx_pixel, niveau_pression]  # N2O (ppbv)
            if np.isnan(concentration):
                continue
            i_lat = int((lat - lat_min) / lat_step)  # Indice cellule latitude
            i_lon = int((lon - lon_min) / lon_step)  # Indice cellule longitude
            if 0 <= i_lat < n_lat and 0 <= i_lon < n_lon:
                nb_mesures[i_lat, i_lon] += 1
                somme_n2o[i_lat, i_lon] += concentration
                somme_n2o_carre[i_lat, i_lon] += concentration**2
        f_gosat.close()

# --- Statistiques par cellule ---
moyenne_n2o = np.full((n_lat, n_lon), np.nan)     # Concentration moyenne (ppbv)
ecart_type_n2o = np.full((n_lat, n_lon), np.nan)  # Écart-type (ppbv)
for i in range(n_lat):
    for j in range(n_lon):
        if nb_mesures[i, j] >= seuil_mesures:
            n = nb_mesures[i, j]
            moyenne_n2o[i, j] = somme_n2o[i, j] / n
            variance = (somme_n2o_carre[i, j] / n) - (moyenne_n2o[i, j])**2
            ecart_type_n2o[i, j] = np.sqrt(variance)

# --- Échelles ---
vmin_nb = 0
vmax_nb = 200
vmin_moy = np.nanmin(moyenne_n2o)
vmax_moy = np.nanmax(moyenne_n2o)
vmin_std = np.nanmin(ecart_type_n2o)
vmax_std = np.nanmax(ecart_type_n2o)
lon_edges = np.arange(lon_min, lon_max + lon_step, lon_step)  # Bords cellules longitude
lat_edges = np.arange(lat_min, lat_max + lat_step, lat_step)  # Bords cellules latitude

# === CARTE 1 : NOMBRE DE MESURES ===
fig = plt.figure(figsize=(14, 7))
ax = plt.axes(projection=ccrs.PlateCarree())
ax.set_global()
ax.add_feature(cfeature.OCEAN, facecolor='lightblue')
ax.add_feature(cfeature.LAND, facecolor='lightgray')
ax.coastlines(linewidth=0.5)
gl = ax.gridlines(linewidth=0.3, color='gray', alpha=0.5)
nb_mesures_masked = np.where(nb_mesures >= seuil_mesures, nb_mesures, np.nan)  # Masque seuil
im = ax.pcolormesh(lon_edges, lat_edges, nb_mesures_masked,
                   cmap='coolwarm', shading='flat', vmin=vmin_nb, vmax=vmax_nb,
                   transform=ccrs.PlateCarree())
cbar = plt.colorbar(im, ax=ax, orientation='horizontal', pad=0.05, aspect=50)
cbar.set_label('Nombre de mesures', fontsize=11, fontweight='bold')
plt.title(f"Nombre de mesures GOSAT par cellule - Mars-Décembre 2019",
          fontsize=14, fontweight='bold', pad=20)
plt.tight_layout()
plt.show()

# === CARTE 2 : CONCENTRATION MOYENNE ===
fig = plt.figure(figsize=(14, 7))
ax = plt.axes(projection=ccrs.PlateCarree())
ax.set_global()
ax.add_feature(cfeature.OCEAN, facecolor='lightblue')
ax.add_feature(cfeature.LAND, facecolor='lightgray')
ax.coastlines(linewidth=0.5)
gl = ax.gridlines(linewidth=0.3, color='gray', alpha=0.5)
cmap = plt.cm.coolwarm.copy()
cmap.set_bad(color='black')  # Cellules invalides en noir
im = ax.pcolormesh(lon_edges, lat_edges, moyenne_n2o,
                   cmap=cmap, shading='flat', vmin=vmin_moy, vmax=vmax_moy,
                   transform=ccrs.PlateCarree())
cbar = plt.colorbar(im, ax=ax, orientation='horizontal', pad=0.05, aspect=50)
cbar.set_label('Concentration moyenne N₂O (ppb)', fontsize=11, fontweight='bold')
plt.title(f"Concentration moyenne N₂O par cellule - Mars-Décembre 2019",
          fontsize=14, fontweight='bold', pad=20)
plt.tight_layout()
plt.show()

# === CARTE 3 : ÉCART-TYPE ===
fig = plt.figure(figsize=(14, 7))
ax = plt.axes(projection=ccrs.PlateCarree())
ax.set_global()
ax.add_feature(cfeature.OCEAN, facecolor='lightblue')
ax.add_feature(cfeature.LAND, facecolor='lightgray')
ax.coastlines(linewidth=0.5)
gl = ax.gridlines(linewidth=0.3, color='gray', alpha=0.5)
cmap = plt.cm.coolwarm.copy()
cmap.set_bad(color='black')
im = ax.pcolormesh(lon_edges, lat_edges, ecart_type_n2o,
                   cmap=cmap, shading='flat', vmin=vmin_std, vmax=vmax_std,
                   transform=ccrs.PlateCarree())
cbar = plt.colorbar(im, ax=ax, orientation='horizontal', pad=0.05, aspect=50)
cbar.set_label('Écart-type N₂O (ppb)', fontsize=11, fontweight='bold')
plt.title(f"Variabilité spatiale N₂O (écart-type) - Mars-Décembre 2019",
          fontsize=14, fontweight='bold', pad=20)
plt.tight_layout()
plt.show()


# ================================================================================
# VI. COLOCALISATION SPATIALE ET TEMPORELLE
# ================================================================================

print("\n" + "=" * 80)
print("COLOCALISATION GOSAT-FTIR")
print("=" * 80)

donnees_colocalisees = []  # Liste de dictionnaires par mesure colocalisée

for num_mois in range(3, 13):
    fichiers_gosat_mois = glob.glob(
        os.path.join(chemin_gosat_base, f"GOSAT2TFTS22019{num_mois:02d}*.h5")
    )
    print(f"  Fichiers GOSAT trouvés: {len(fichiers_gosat_mois)}")
    for fichier_gosat in fichiers_gosat_mois:
        f_gosat = h5py.File(fichier_gosat, 'r')
        latitudes_gosat = extraire_donnees_gosat(f_gosat, 6, 0)
        longitudes_gosat = extraire_donnees_gosat(f_gosat, 6, 1)
        profils_n2o = extraire_donnees_gosat(f_gosat, 3, 2)
        timestamps_gosat = extraire_donnees_gosat(f_gosat, 5, 4)
        nombre_pixels = latitudes_gosat.shape[0]
        nombre_niveaux = profils_n2o.shape[1]
        # Nettoyage
        profils_n2o_nettoyes = np.full((nombre_pixels, nombre_niveaux), np.nan)
        for i in range(nombre_pixels):
            for k in range(nombre_niveaux):
                if 0.323 <= profils_n2o[i, k] <= 0.334:
                    profils_n2o_nettoyes[i, k] = profils_n2o[i, k] * 1000
        # Double boucle stations × pixels
        for idx_station in range(len(coordonnees_stations)):
            lat_station = coordonnees_stations[idx_station, 0]  # Latitude station (°)
            lon_station = coordonnees_stations[idx_station, 1]  # Longitude station (°)
            for idx_pixel in range(nombre_pixels):
                # Filtre spatial (Haversine)
                dist_km = distance_haversine(lat_station, lon_station,
                                             latitudes_gosat[idx_pixel], longitudes_gosat[idx_pixel])
                if dist_km < rayon_colocalisation_km:
                    # Filtre temporel
                    date_gosat = datetime.datetime.fromisoformat(timestamps_gosat[idx_pixel].decode())
                    mois_gosat = date_gosat.strftime('%Y-%m')
                    if mois_gosat in mois_ftir_disponibles:
                        concentration_gosat = profils_n2o_nettoyes[idx_pixel, niveau_pression]  # N2O (ppbv)
                        if not np.isnan(concentration_gosat):
                            nom_station = identifier_station(lat_station, lon_station)
                            donnees_colocalisees.append({
                                'Date': mois_gosat,
                                'Station': nom_station,
                                'Latitude_Station': lat_station,
                                'Longitude_Station': lon_station,
                                'Latitude_GOSAT': latitudes_gosat[idx_pixel],
                                'Longitude_GOSAT': longitudes_gosat[idx_pixel],
                                'N2O_GOSAT': concentration_gosat
                            })
        f_gosat.close()

print(f"\nNombre total de colocalisations: {len(donnees_colocalisees)}")


# ================================================================================
# VII. CRÉATION DE LA BASE DE DONNÉES COLOCALISÉES
# ================================================================================

print("\n" + "=" * 80)
print("CRÉATION DU FICHIER DE DONNÉES COLOCALISÉES")
print("=" * 80)

df_colocalisees = pd.DataFrame(donnees_colocalisees)
df_colocalisees = df_colocalisees[['Date', 'Station', 'Latitude_Station', 'Longitude_Station',
                                    'Latitude_GOSAT', 'Longitude_GOSAT', 'N2O_GOSAT']]

# Sauvegarde fichier texte
fichier_sortie = os.path.join(chemin_sortie, "donnees_colocalisees.txt")
with open(fichier_sortie, 'w') as f:
    f.write("Date | Station | Position_Station | Position_GOSAT | N2O_GOSAT\n")
    f.write("=" * 80 + "\n")
    for _, row in df_colocalisees.iterrows():
        f.write(f"{row['Date']} | {row['Station']} | ")
        f.write(f"{row['Latitude_Station']:.2f},{row['Longitude_Station']:.2f} | ")
        f.write(f"{row['Latitude_GOSAT']:.2f},{row['Longitude_GOSAT']:.2f} | ")
        f.write(f"{row['N2O_GOSAT']:.2f}\n")

densi_min_global = 323  # Min échelle concentration (ppbv)
densi_max_global = 334  # Max échelle concentration (ppbv)

print(f"Répartition par station:")
print(df_colocalisees['Station'].value_counts())


# ================================================================================
# VIII. CARTES AVEC FILTRES (STATIONS)
# ================================================================================

# --- 1. Cartes mensuelles colocalisées ---

print("\n" + "=" * 80)
print("GÉNÉRATION DES CARTES MENSUELLES AVEC FILTRES")
print("=" * 80)

for num_mois in range(3, 13):
    mois_str = f"2019-{num_mois:02d}"
    donnees_mois = df_colocalisees[df_colocalisees['Date'] == mois_str]
    if len(donnees_mois) == 0:
        print(f"  Aucune donnée pour ce mois")
        continue
    fig = plt.figure(figsize=(14, 7))
    projection_carte = ccrs.PlateCarree()
    ax = plt.axes(projection=projection_carte)
    ax.set_global()
    ax.add_feature(cfeature.OCEAN, facecolor='dodgerblue')
    ax.add_feature(cfeature.LAND, facecolor='wheat')
    ax.add_feature(cfeature.LAKES, facecolor='deepskyblue')
    ax.add_feature(cfeature.RIVERS, linewidth=0.5, edgecolor='blue')
    ax.coastlines(linewidth=0.5, color='black', resolution='110m')
    gl = ax.gridlines(draw_labels=True, linewidth=0.3, color='gray', alpha=0.5)
    gl.top_labels = False
    gl.right_labels = False
    # Points GOSAT colocalisés
    scatter = ax.scatter(
        donnees_mois['Longitude_GOSAT'], donnees_mois['Latitude_GOSAT'],
        c=donnees_mois['N2O_GOSAT'], cmap='coolwarm', s=5, alpha=1,
        vmin=densi_min_global, vmax=densi_max_global, transform=projection_carte
    )
    cbar = plt.colorbar(scatter, ax=ax, orientation='horizontal', pad=0.05, aspect=50)
    cbar.set_label('Concentration N₂O (ppb)', fontsize=11, fontweight='bold')
    # Cercles et noms stations
    for idx, coords in enumerate(coordonnees_stations):
        lat, lon = coords[0], coords[1]
        lon_cercle, lat_cercle = generer_cercle(rayon_colocalisation_km, lon, lat)
        ax.plot(lon_cercle, lat_cercle, color='crimson', linewidth=2, alpha=0.8, transform=projection_carte)
        nom_station = identifier_station(lat, lon).split('(')[0].strip()
        ax.text(lon, lat - 12, nom_station, fontsize=9, fontweight='bold',
                ha='center', va='top', color='darkred',
                bbox=dict(facecolor='white', alpha=0.7, edgecolor='none', pad=2),
                transform=projection_carte)
    # Marqueurs stations
    ax.scatter(coordonnees_stations[:, 1], coordonnees_stations[:, 0],
               color='red', marker='^', s=100, edgecolor='black', linewidth=0.5,
               transform=projection_carte, label='Stations FTIR')
    plt.title(f"Concentration N₂O (niveau {niveau_pression}) - {noms_mois[num_mois-3].upper()} 2019",
              fontsize=14, fontweight='bold', pad=20)
    plt.xlabel('Longitude', fontsize=11)
    plt.ylabel('Latitude', fontsize=11)
    plt.legend(loc='lower left', fontsize=10)
    plt.tight_layout()
    plt.show()


# --- 2. Cartes quotidiennes colocalisées ---

print("\n" + "=" * 80)
print("GÉNÉRATION DES CARTES QUOTIDIENNES AVEC FILTRES")
print("=" * 80)

compteur_jour = 0  # Compteur jours traités
for num_mois in range(3, 13):
    fichiers_gosat_mois = sorted(glob.glob(
        os.path.join(chemin_gosat_base, f"GOSAT2TFTS22019{num_mois:02d}*.h5")
    ))
    for fichier_gosat in fichiers_gosat_mois:
        compteur_jour += 1
        nom_fichier = os.path.basename(fichier_gosat)
        jour = nom_fichier[17:19]  # Extraction jour depuis nom fichier
        f_gosat = h5py.File(fichier_gosat, 'r')
        latitudes_gosat = extraire_donnees_gosat(f_gosat, 6, 0)
        longitudes_gosat = extraire_donnees_gosat(f_gosat, 6, 1)
        profils_n2o = extraire_donnees_gosat(f_gosat, 3, 2)
        timestamps_gosat = extraire_donnees_gosat(f_gosat, 5, 4)
        nombre_pixels = latitudes_gosat.shape[0]
        nombre_niveaux = profils_n2o.shape[1]
        # Nettoyage
        profils_n2o_nettoyes = np.full((nombre_pixels, nombre_niveaux), np.nan)
        for i in range(nombre_pixels):
            for k in range(nombre_niveaux):
                if 0.323 <= profils_n2o[i, k] <= 0.334:
                    profils_n2o_nettoyes[i, k] = profils_n2o[i, k] * 1000
        # Colocalisations du jour
        latitudes_coloc = []      # Latitudes colocalisées (°)
        longitudes_coloc = []     # Longitudes colocalisées (°)
        concentrations_coloc = [] # Concentrations N2O (ppbv)
        for idx_station in range(len(coordonnees_stations)):
            lat_station = coordonnees_stations[idx_station, 0]
            lon_station = coordonnees_stations[idx_station, 1]
            for idx_pixel in range(nombre_pixels):
                dist_km = distance_haversine(lat_station, lon_station,
                          latitudes_gosat[idx_pixel], longitudes_gosat[idx_pixel])
                if dist_km < rayon_colocalisation_km:
                    date_gosat = datetime.datetime.fromisoformat(timestamps_gosat[idx_pixel].decode())
                    mois_gosat = date_gosat.strftime('%Y-%m')
                    if mois_gosat in mois_ftir_disponibles:
                        concentration = profils_n2o_nettoyes[idx_pixel, niveau_pression]
                        if not np.isnan(concentration):
                            latitudes_coloc.append(latitudes_gosat[idx_pixel])
                            longitudes_coloc.append(longitudes_gosat[idx_pixel])
                            concentrations_coloc.append(concentration)
        f_gosat.close()
        # Si aucune colocalisation, passer au jour suivant
        if len(latitudes_coloc) == 0:
            print(f"  Aucune colocalisation")
            continue
        # Carte quotidienne
        fig = plt.figure(figsize=(14, 7))
        projection_carte = ccrs.PlateCarree()
        ax = plt.axes(projection=projection_carte)
        ax.set_global()
        ax.add_feature(cfeature.BORDERS, linewidth=0.5, edgecolor='gray')
        ax.add_feature(cfeature.OCEAN, facecolor='dodgerblue')
        ax.add_feature(cfeature.LAND, facecolor='wheat')
        ax.add_feature(cfeature.LAKES, facecolor='deepskyblue', alpha=0.4)
        ax.add_feature(cfeature.RIVERS, linewidth=0.5, edgecolor='blue')
        ax.coastlines(linewidth=0.5, color='black', resolution='110m')
        gl = ax.gridlines(draw_labels=True, linewidth=0.3, color='gray', alpha=0.5)
        gl.top_labels = False
        gl.right_labels = False
        scatter = ax.scatter(longitudes_coloc, latitudes_coloc, c=concentrations_coloc,
                             cmap='coolwarm', s=12, alpha=1,
                             vmin=densi_min_global, vmax=densi_max_global, transform=projection_carte)
        cbar = plt.colorbar(scatter, ax=ax, orientation='horizontal', pad=0.05, aspect=50)
        cbar.set_label('Concentration N₂O (ppb)', fontsize=11, fontweight='bold')
        for idx, coords in enumerate(coordonnees_stations):
            lat, lon = coords[0], coords[1]
            lon_cercle, lat_cercle = generer_cercle(rayon_colocalisation_km, lon, lat)
            ax.plot(lon_cercle, lat_cercle, color='crimson', linewidth=2, alpha=0.8, transform=projection_carte)
            nom_station = identifier_station(lat, lon).split('(')[0].strip()
            ax.text(lon, lat - 12, nom_station, fontsize=9, fontweight='bold',
                    ha='center', va='top', color='darkred',
                    bbox=dict(facecolor='white', alpha=0.7, edgecolor='none', pad=2),
                    transform=projection_carte)
        ax.scatter(coordonnees_stations[:, 1], coordonnees_stations[:, 0],
                   color='red', marker='^', s=60, edgecolor='black', linewidth=0.5,
                   transform=projection_carte, label='Stations FTIR')
        plt.title(f"Concentration N₂O (niveau {niveau_pression}) - {jour} {noms_mois[num_mois-3]} 2019",
                  fontsize=14, fontweight='bold', pad=20)
        plt.xlabel('Longitude', fontsize=11)
        plt.ylabel('Latitude', fontsize=11)
        plt.legend(loc='lower left', fontsize=10)
        plt.tight_layout()
        plt.show()

print(f"\nNombre de colocalisations: {len(donnees_colocalisees)}")